﻿
function InitiateAlert(strAlertMessage)
{
    alert(strAlertMessage);
}